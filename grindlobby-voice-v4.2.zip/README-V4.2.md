GrindLobby Voice Engine v4.2

Mudança principal:
- Teste de microfone agora é CONTÍNUO e em tempo real.
- Não grava nem cria arquivo.
- Clique em "Testar microfone" para ouvir sua voz.
- Continua até clicar em "Sair do teste".
- Recomenda-se usar fones para evitar microfonia.

Aplicação:
1) substituir components/AudioHost.tsx
2) acrescentar audio-v42.css ao final de app/globals.css
3) npm run build
