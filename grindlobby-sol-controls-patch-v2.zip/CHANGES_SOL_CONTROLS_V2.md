# GrindLobby controls patch v2

Foco exclusivo desta revisão:

- botão de mic local usa diretamente a API LiveKit do Voice Engine;
- botão de mic remoto silencia/desfaz silêncio do participante apenas para o cliente atual (não altera o microfone do outro usuário no servidor);
- sliders reais para ganho do mic local e volume remoto;
- menu de 3 pontos com presets de ganho/volume e copiar usuário;
- Music Bot com busca, fila, play/pause, próxima/anterior, loop e volume usando faixas Jamendo quando `JAMENDO_CLIENT_ID` estiver configurado;
- painel de ping tenta primeiro RTT real da mídia LiveKit via RTCStats e cai para RTT HTTP do GrindLobby quando não há track de mídia disponível.

Observação: mutar remotamente o microfone de outra pessoa para todos exige permissão de moderação no servidor LiveKit. Esta revisão mantém o comportamento seguro/local para participantes remotos.
