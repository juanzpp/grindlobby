# GrindLobby — member controls, music search and real RTT

Changes in this patch:

- Member microphone icon is now an actual control:
  - own row: mutes/unmutes your LiveKit microphone;
  - remote row: locally mutes/unmutes that participant for you.
- Inline volume sliders:
  - own row: controls microphone gain (0–200%) before the track is published to LiveKit;
  - remote row: controls that participant's playback volume (0–100%).
- Three-dot menu now includes working actions such as mute/unmute, restore volume, 50% remote volume and copy username.
- Microphone gain is applied to the actual published LiveKit audio through a WebAudio GainNode.
- Music bot now searches the Jamendo catalog through `/api/music/search`, builds a real queue, and plays the returned audio streams with pause/skip/loop/volume controls.
- Production music search requires `JAMENDO_CLIENT_ID`; development can use Jamendo's documented read-only test client id.
- Connection panel now measures real browser-to-GrindLobby-server RTT through `/api/ping`, keeps recent samples and shows the measured latency in milliseconds.

No database schema or Supabase migration changes are included.
