import {NextResponse} from 'next/server'
import {createClient} from '@/lib/supabase/server'
import {createAdminClient} from '@/lib/supabase/admin'
export async function DELETE(_:Request,{params}:{params:Promise<{id:string,userId:string}>}){
 const {id,userId}=await params;const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:'Não autorizado.'},{status:401});
 const admin=createAdminClient();const {data:lobby}=await admin.from('lobbies').select('owner_id').eq('id',id).maybeSingle();if(!lobby)return NextResponse.json({error:'Lobby não encontrado.'},{status:404});if(lobby.owner_id!==user.id)return NextResponse.json({error:'Apenas o host pode remover membros.'},{status:403});if(userId===user.id)return NextResponse.json({error:'O host não pode remover a si mesmo.'},{status:400});
 const {error}=await admin.from('lobby_members').delete().eq('lobby_id',id).eq('user_id',userId);if(error)return NextResponse.json({error:'Não foi possível remover o player.'},{status:500});return NextResponse.json({ok:true});
}
