# GrindLobby Audio Host v4

Patch seguro para a versão atual do GrindLobby.

## O que adiciona
- painel Voice Engine dentro do lobby
- seleção de microfone e saída
- medidor de voz
- mute/unmute
- sensibilidade
- redução de ruído
- cancelamento de eco
- ganho automático
- volume de entrada/saída preparado para mixer WebRTC
- base para ICE/TURN/SFU posterior

## Aplicação
Este ZIP NÃO deve ser extraído cegamente por cima do projeto, porque o LobbyRoom atual contém lógica real de lobby.
Copie `components/AudioHost.tsx` para o projeto e faça as duas alterações abaixo em `components/LobbyRoom.tsx`.

1. Adicione:
import AudioHost from './AudioHost';

2. Dentro de `<aside className="room-side">`, antes do card SESSION, adicione:
<AudioHost enabled={lobby.isMember}/>

3. Acrescente o conteúdo de `audio-host.css` ao final de `app/globals.css`.

Depois:
npm run build
git add .
git commit -m "Add GrindLobby Audio Host v4"
git push

Observação: esta etapa implementa captura/processamento local real do microfone e UI. Comunicação de voz entre usuários exige a próxima camada de sinalização WebRTC + TURN/SFU.
